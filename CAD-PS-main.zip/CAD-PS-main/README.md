# CAD-PS
## Sobre:
O codigo é dividido em duas pastas uma com um codigo feito de forma sequencial e outra com o código paralelizado usando a biblioteca omp.h

## Como usar:
1. Entre na pasta referente ao codigo que deseja executar (sequencial ou paralelo)
2. utilize o comando ´´´make all´´´ para criar o executavel
3. Utilize ´´´make run´´´ para rodar
4. Escolha o numero de regioes cidades e alunos
